reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    overflow: hidden;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: 500;
    line-height: 120%;
  }

  button {
    cursor: pointer;
    border-radius: 4px;
    border: none;
    box-shadow: 1px 1px 4px 0px rgba(124, 124, 124, 0.20);
    color: #ffffff;
    margin-bottom: 5px;
    background-color: #4c00ff;
  }

  #wrapper {
    box-sizing: border-box;
    max-width: 210px;
    max-height: 560px;
    border-radius: 4px;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
    overflow: auto;
  }

  #search {
    margin: 8px 0;
  }

  #start-btn {
    display: block;
    width: 100%;
    padding: 4px 24px;
  }
</style>

<div id="wrapper">
  <button type="button" id="start-btn">Start</button>
  <div id="output"></div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.7.1/jszip.min.js"></script>

<script>

  let reearth, cesium, layers, property, zipFileContent;
  let fileData = []
  let output = document.getElementById('output');

  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    zipFileContent = e.data.property.default.url;
  })



  function convertData() {
    // Fetch the ZIP file from the specified path
    fetch(zipFileContent)
      .then(response => {
        if (response.ok) {
          return response.arrayBuffer(); // Get the file as an array buffer
        }
        throw new Error('Network response was not ok.');
      })
      .then(data => {
        let zip = new JSZip(); // Create a new JSZip instance
        return zip.loadAsync(data); // Load the ZIP file data
      })
      .then(zip => {
        output.innerHTML = ''; // Clear any existing content
        // Iterate through each file in the ZIP
        const zipName = Object.keys(zip.files)[0];
        const regex = new RegExp('^' + zipName + '.*\\.png$', 'i'); // Create a regex to match filenames starting with zipName and ending with .png
        const pngRegex = new RegExp('^' + zipName + '(.*)\\.png$', 'i'); // Regex to match filenames starting with zipName and ending with .png, capturing the filename
        const geojsonRegex = new RegExp('^' + zipName + '.*countries\\.geojson$', 'i'); // Regex to match filenames with zipName and ending with countries.geojson
        const jsonRegex = new RegExp('^' + zipName + '.*countries\\.json$', 'i'); // Regex to match filenames with zipName and ending with countries.json
        let geojsonData
        let imageArrData = {}

        Object.keys(zip.files).forEach(filename => {
          if (regex.test(filename)) { // Check if the filename matches the regex
            // Convert the file to a base64-encoded string to ge images
            zip.files[filename].async('base64').then(base64 => {
              let img = document.createElement('img');
              img.src = 'data:image/png;base64,' + base64;
              img.style.maxWidth = '100%';
              output.appendChild(img); 
              const match = filename.match(pngRegex);
              const pngFileName = match[1].toUpperCase(); 
              imageArrData[pngFileName] = img.src
            });
          }

           // get GeoJSON 
          if (geojsonRegex.test(filename)) { 
            zip.files[filename].async('string').then(content => {
              // Parse the GeoJSON content
              geojsonData = JSON.parse(content);
              handleGeoJSON(geojsonData, imageArrData);
            });
          }
        });

      })
      .catch(error => {
        console.error('There was a problem with the fetch operation:', error); 
      });
  }

  function handleGeoJSON(geojson, imageArr) {
    console.log(imageArr);
    geojson.features.forEach(feature => {
      const longitude = feature.geometry.coordinates[0];
      const latitude = feature.geometry.coordinates[1];
      const country = feature.properties.COUNTRY;
      const iso = feature.properties.ISO;
      const url = imageArr[iso];

      addMarker(longitude, latitude, iso, url, country)
    });
  }


  function addMarker(lng, lat, iso, url, country) {
    let markerId = reearth.layers.add({
      extensionId: "marker",
      isVisible: true,
      title: country,
      property: {
        default: {
          image: url,
          imageSize: 0.5,
          location: {
            lat: lat,
            lng: lng,
          },
          label: true,
          labelText: country,
          labelTypography: {
            fontSize: 18
          }
        },
      },
      infobox: {
        blocks: [
          {
            extensionId: "textblock",
            pluginId: "reearth",
            property: {
              default: {
                src: "",
              }
            }
          }
        ],
      },
      tags: [],
    });

    reearth.camera.flyTo({
      lng: lng,
      lat: lat,
      height: 100000,
    }, {
      duration: 2
    });
  }

  document.getElementById('start-btn').addEventListener('click', convertData)

</script>

`,);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
property: reearth.widget.property,
layers: reearth.layers.layers
})
}