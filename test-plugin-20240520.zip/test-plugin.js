reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    overflow: hidden;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: 500;
    line-height: 120%;
  }

  button {
    cursor: pointer;
    border-radius: 4px;
    border: none;
    box-shadow: 1px 1px 4px 0px rgba(124, 124, 124, 0.20);
    color: #ffffff;
    margin-bottom: 5px;
    background-color: #4c00ff;
  }

  #wrapper {
    box-sizing: border-box;
    max-width: 50px;
    max-height: 50px;
    border-radius: 4px;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
    overflow: auto;
  }

  #search {
    margin: 8px 0;
  }

  #start-btn {
    display: block;
    width: 100%;
    padding: 4px 24px;
  }
</style>

<div id="wrapper">
  <div class="logo">Logo</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/fflate@0.6.9/umd/index.min.js"></script>

<script>

  let reearth, cesium, layers, property, newProperty, markerId;

  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    newProperty = e.data.property;
    layers = reearth.layers.layers;

    if (JSON.stringify(property) != JSON.stringify(newProperty)) {
      property = newProperty;
      zipFileContent = property.default.url;
      CleanAll()
      convertData(zipFileContent)
    }

  })


  function convertData(zipFileContent) {
    fetch(zipFileContent)
      .then(response => {
        if (response.ok) {
          return response.arrayBuffer(); // Get the data as an array buffer
        }
        throw new Error('Network response was not ok.');
      })
      .then(data => {
        fflate.unzip(new Uint8Array(data), (err, unzipped) => {
          if (err) {
            console.error('There was a problem with unzipping:', err);
            return;
          }

          const zipName = Object.keys(unzipped)[0];
          const regex = new RegExp('^' + zipName + '.*\\.png$', 'i'); // Regex to match filenames starting with zipName and ending with .png
          const pngRegex = new RegExp('^' + zipName + '(.*)\\.png$', 'i'); // Regex to match filenames starting with zipName and ending with .png, capturing the filename
          const geojsonRegex = new RegExp('^' + zipName + '.*countries\\.geojson$', 'i'); // Regex to match filenames with zipName and ending with countries.geojson
          const jsonRegex = new RegExp('^' + zipName + '.*countries\\.json$', 'i'); // Regex to match filenames with zipName and ending with countries.json

          let geojsonData
          let imageArrData = []

          for (const [key, value] of Object.entries(unzipped)) {
            if (regex.test(key)) {
              // Get PNG images
              const match = key.match(pngRegex);
              const pngFileName = match[1].toUpperCase(); // Captured the name of the PNG file to compare it with ISO in GeoJson file to upload correct images 
              const base64 = btoa(String.fromCharCode(...new Uint8Array(value)));
              const imgSrc = 'data:image/png;base64,' + base64;
              imageArrData[pngFileName] = imgSrc;
            }

            if (geojsonRegex.test(key)) {
              // Get GeoJSON data and declare it as a JSON object in geojsonData
              const content = new TextDecoder().decode(value);
              geojsonData = JSON.parse(content);
            }
          }

          handleGeoJSON(geojsonData, imageArrData);
        })
      })
      .catch(error => {
        console.error('There was a problem with the fetch operation:', error); // Handle any errors
      });
  }


  function handleGeoJSON(geojson, imageArr) {
    geojson.features.forEach(feature => {
      const longitude = feature.geometry.coordinates[0];
      const latitude = feature.geometry.coordinates[1];
      const country = feature.properties.COUNTRY;
      const iso = feature.properties.ISO;
      const url = imageArr[iso];
      addMarker(longitude, latitude, url, country);
    });
  }


  function addMarker(lng, lat, url, country) {

// if (markerId) {
//    reearth.layers.overrideProperty(markerId, {
//        title: country,
//        property: {
//          default: {
//            image: url,
//            imageSize: 0.2,
//            location: {
//              lat: lat,
//              lng: lng,
//            },
//          },
//        },
//        infobox: {
//          blocks: [
//            {
//              extensionId: "imageblock",
//              pluginId: "reearth",
//              property: {
//                default: {
//                  image: url,
//                  fullSize: true
//                }
//              }
//            }
//          ],
//        },
//    })
// } else {

    markerId = reearth.layers.add({
      extensionId: "marker",
      isVisible: true,
      title: country,
      property: {
        default: {
          image: url,
          imageSize: 0.2,
          location: {
            lat: lat,
            lng: lng,
          },
        },
      },
      infobox: {
        blocks: [
          {
            extensionId: "imageblock",
            pluginId: "reearth",
            property: {
              default: {
                image: url,
                fullSize: true
              }
            }
          }
        ],
      },
    });
// }

    reearth.camera.flyTo({
      lng: lng,
      lat: lat,
      height: 100000,
    }, {
      duration: 2
    });

  }

  function CleanAll() {
    let filteredLayers = reearth.layers.findAll(layer => layer.type === 'marker');

    filteredLayers.forEach(layer => {
      reearth.layers.hide(layer.id)
    });

  }


</script>
`,);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
property: reearth.widget.property,
layers: reearth.layers.layers
})
}

reearth.on("message", (msg) => {
if (msg.type == "clean") {
reearth.layers.overrideProperty(msg.layerId, {
default: {
imageSize: 0,
},
})
}
})