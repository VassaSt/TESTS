reearth.ui.show(`
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600&family=Roboto:wght@400;500;700&display=swap');

  html,
  body {
    margin: 0;
    overflow: hidden;
    font-family: "Roboto";
    font-size: 12px;
    font-weight: 500;
    line-height: 120%;
  }

  button {
    cursor: pointer;
    border-radius: 4px;
    border: none;
    box-shadow: 1px 1px 4px 0px rgba(124, 124, 124, 0.20);
    color: #ffffff;
    margin-bottom: 5px;
    background-color: #4c00ff;
  }

  #wrapper {
    box-sizing: border-box;
    max-width: 210px;
    max-height: 560px;
    border-radius: 4px;
    background-color: #ffffff;
    padding: 12px;
    border-radius: 4px;
    overflow: auto;
  }

  #start-btn {
    display: block;
    width: 100%;
    padding: 4px 24px;
  }
</style>
<div id="wrapper">
  <button id="start-btn"> START </button>
</div>

<script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
<script src='https://unpkg.com/@turf/turf@6/turf.min.js'></script>
<script>
  let reearth, cesium, property, layers, layerId;
  const btn = document.getElementById("start-btn");    
  
  const czml = [
  {
    id: "document",
    name: "CZML Polygon - Interpolating References",
    version: "1.0",
  },
  {
    id: "dynamicPolygon",
    name: "Dynamic Polygon with Reference Properties",
    availability: "2012-08-04T16:00:00Z/2012-08-04T17:00:00Z",
    polygon: {
      positions: {
        references: ["v1#position", "v2#position", "v3#position"],
      },
      perPositionHeight: true,
      material: {
        solidColor: {
          color: [
            {
              interval: "2012-08-04T16:00:00Z/2012-08-04T16:19:60Z",
              rgba: [255, 0, 0, 255],
            },
            {
              interval: "2012-08-04T16:20:00Z/2012-08-04T16:29:60Z",
              rgba: [0, 255, 0, 200],
            },
            {
              interval: "2012-08-04T16:30:00Z/2012-08-04T17:00:00Z",
              rgba: [0, 0, 255, 155],
            },
          ],
        },
      },
    },
  },
  {
    id: "v1",
    position: {
      interpolationAlgorithm: "LINEAR",
      interpolationDegree: 1,
      interval: "2012-08-04T16:00:00Z/2012-08-04T17:00:00Z",
      epoch: "2012-08-04T16:00:00Z",
      cartographicDegrees: [
        0,
        -60,
        35,
        30000,
        160,
        -65,
        35,
        5000000,
        400,
        -70,
        40,
        20000,
        800,
        -62,
        45,
        200000,
        1800,
        -65,
        40,
        650000,
        3600,
        -60,
        35,
        3000,
      ],
    },
  },
  {
    id: "v2",
    position: {
      interval: "2012-08-04T16:00:00Z/2012-08-04T17:00:00Z",
      cartographicDegrees: [-45.0, 20, 4000000],
    },
  },
  {
    id: "v3",
    position: {
      interpolationAlgorithm: "LINEAR",
      interpolationDegree: 1,
      interval: "2012-08-04T16:00:00Z/2012-08-04T17:00:00Z",
      epoch: "2012-08-04T16:00:00Z",
      cartographicDegrees: [
        0,
        -45,
        60,
        4000,
        400,
        -40,
        70,
        2000000,
        1000,
        -35,
        75,
        100000,
        3600,
        -45,
        65,
        3000,
      ],
    },
  },
];


  window.addEventListener("message", async function (e) {
    if (e.source !== parent) return;
    reearth = e.source.reearth;
    layers = reearth.layers.layers;
    cesium = reearth.Cesium;
    newProperty = e.data.property;

  });



  btn.addEventListener('click', loadData);

  function loadData() {
    czmlInLayer(czml)
  }

  function czmlInLayer(czml) {

    if (layerId) {
      reearth.layers.overrideProperty(layerId, {
        data: {
          url: czml,
        }
      })
    } else {
      layerId = reearth.layers.add({
        type: "simple",

        // 1. how to load data
        data: {
          type: "czml",
          url: czml,
        },
      });

    }


    reearth.camera.lookAt({
      lng: czml[1].position.cartographicDegrees[1],
      lat: czml[1].position.cartographicDegrees[0],
      height: 1500000.0,
      pitch: -1.5,
    }, {
      duration: 2
    });

    console.log(layerId);
  }

</script>
`,);

reearth.on("update", send);
send();

function send() {
reearth.ui.postMessage({
property: reearth.widget.property,
layer: reearth.layers.layers
})
}